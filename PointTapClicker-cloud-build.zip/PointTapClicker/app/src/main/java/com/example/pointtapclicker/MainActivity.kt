package com.example.pointtapclicker

import android.app.Activity
import android.content.Intent
import android.graphics.Point
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(TapAccessibilityService.PREFS, Context.MODE_PRIVATE) }
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dm = resources.displayMetrics
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101010.toInt())
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFFF4F4F4.toInt())
        }
        root.addView(label("POINT TAP CLICKER", 24f))
        root.addView(label("Point A = target coordinates in screen pixels. Point B = floating TAP button."))
        root.addView(label("Current display: ${dm.widthPixels} × ${dm.heightPixels} px"))
        xInput = EditText(this).apply { hint = "Point A X (pixels)"; inputType = 2; setText(prefs.getInt("target_x", dm.widthPixels / 2).toString()); setTextColor(-1); setHintTextColor(0xFFAAAAAA.toInt()) }
        yInput = EditText(this).apply { hint = "Point A Y (pixels)"; inputType = 2; setText(prefs.getInt("target_y", dm.heightPixels / 2).toString()); setTextColor(-1); setHintTextColor(0xFFAAAAAA.toInt()) }
        root.addView(xInput, LinearLayout.LayoutParams(-1, -2))
        root.addView(yInput, LinearLayout.LayoutParams(-1, -2))
        val save = Button(this).apply { text = "SAVE POINT A"; setOnClickListener { saveTarget() } }
        root.addView(save)
        val accessibility = Button(this).apply {
            text = "1. ENABLE ACCESSIBILITY SERVICE"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accessibility)
        val overlayInfo = Button(this).apply {
            text = "2. SHOW / REFRESH FLOATING BUTTON"
            setOnClickListener {
                saveTarget()
                if (isServiceEnabled()) {
                    sendBroadcast(Intent(TapAccessibilityService.ACTION_SHOW).setPackage(packageName))
                    Toast.makeText(this@MainActivity, "Service enabled. Open your game and use TAP bubble.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, "First enable Point Tap Clicker in Accessibility settings.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
        }
        root.addView(overlayInfo)
        status = label("Local only • no internet required • one tap per button press", 14f)
        root.addView(status)
        root.addView(label("Note: Coordinates are physical screen pixels. They may shift if rotation, resolution, or game layout changes. This app cannot guarantee zero delay or work in every game.", 14f))
        setContentView(root)
    }

    private fun saveTarget() {
        val x = xInput.text.toString().toIntOrNull()
        val y = yInput.text.toString().toIntOrNull()
        if (x == null || y == null || x < 0 || y < 0) {
            Toast.makeText(this, "Enter valid non-negative X and Y pixels.", Toast.LENGTH_SHORT).show(); return
        }
        prefs.edit().putInt("target_x", x).putInt("target_y", y).apply()
        Toast.makeText(this, "Point A saved: ($x, $y)", Toast.LENGTH_SHORT).show()
    }

    private fun isServiceEnabled(): Boolean {
        val expected = "$packageName/${TapAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }
}
