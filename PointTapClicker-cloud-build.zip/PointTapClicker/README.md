# PointTapClicker

Native Android Kotlin sample: floating trigger button and AccessibilityService gesture dispatch for a single tap at configured screen coordinates.

## Build

- Android Gradle Plugin 8.9.2
- Gradle 8.11.1
- JDK 17
- Android SDK 35
- Minimum Android 8.0 (API 26)

### Build locally

```sh
gradle assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

### Build without a laptop

See [BUILD-ON-PHONE.md](BUILD-ON-PHONE.md). The included GitHub Actions workflow builds the APK in the cloud and uploads it as an artifact.

## Limitations

Android accessibility gestures are not zero-latency and cannot guarantee identical behavior in every game. Overlay touch handling and gesture dispatch can be affected by Android version, device settings, game input handling, and security protections. Test carefully before relying on it.
