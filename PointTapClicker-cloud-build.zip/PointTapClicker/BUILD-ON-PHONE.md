# Build the APK using only your Android phone

You do not need a laptop or Android Studio. GitHub builds this project in the cloud.

1. In your phone browser, sign in to https://github.com/ and create a **new public repository** named `PointTapClicker`. Do not initialize it with a README, license, or .gitignore.
2. Download and extract `PointTapClicker-source.zip` on your phone. If your file manager cannot extract ZIPs, use a trusted archive app.
3. Open the new repository on GitHub. Choose **Add file → Upload files** and upload the *contents* of the `PointTapClicker` folder, including the hidden `.github/workflows/build-apk.yml` file. If GitHub's mobile upload does not show hidden folders or upload folders properly, use the GitHub website's desktop-site option or GitHub's web editor to create `.github/workflows/build-apk.yml` with the workflow content from this project.
4. Commit the uploaded files to the `main` branch.
5. Open the repository's **Actions** tab, select **Build PointTapClicker APK**, tap **Run workflow**, then **Run workflow** again.
6. Wait for the run to finish with a green check. Open that run, scroll to **Artifacts**, and download `PointTapClicker-debug-apk`.
7. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Tap it to install; Android may ask you to allow installs from your browser/files app.

Notes:
- The APK is a debug build and is not Play Store signed for publishing.
- Review the source code before uploading it to a public repository. A public repository makes its source code visible to everyone.
- GitHub's mobile upload interface may not handle hidden `.github` folders well; if it fails, use the repository's web editor or a Git client app.
- The build workflow does not prove the clicker works in every game. Grant overlay and Accessibility permissions carefully and test in a safe app first.
