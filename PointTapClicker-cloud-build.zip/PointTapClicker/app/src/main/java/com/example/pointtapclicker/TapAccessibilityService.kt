package com.example.pointtapclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast

class TapAccessibilityService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var gestureBusy = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_SHOW) showBubble()
            if (intent?.action == ACTION_HIDE) removeBubble()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val filter = IntentFilter().apply { addAction(ACTION_SHOW); addAction(ACTION_HIDE) }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun showBubble() {
        if (!::wm.isInitialized || bubble != null) return
        val view = TextView(this).apply {
            text = "TAP"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xEEB8860B.toInt())
            gravity = Gravity.CENTER
            elevation = 12f
            contentDescription = "Point A click trigger"
            setOnClickListener { sendTargetTap() }
            setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragging = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; dragging = false; return true }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                            if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) dragging = true
                            if (dragging) { lp.x = startX + dx; lp.y = startY + dy; wm.updateViewLayout(v, lp) }
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!dragging) v.performClick()
                            return true
                        }
                    }
                    return false
                }
            })
        }
        val type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val params = WindowManager.LayoutParams(dp(62), dp(62), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(20); y = dp(220)
        }
        try { wm.addView(view, params); bubble = view } catch (_: Exception) {
            Toast.makeText(this, "Could not create floating button on this device.", Toast.LENGTH_LONG).show()
        }
    }

    private fun sendTargetTap() {
        if (gestureBusy) return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val x = prefs.getInt("target_x", -1)
        val y = prefs.getInt("target_y", -1)
        if (x < 0 || y < 0) { Toast.makeText(this, "Set Point A in the app first.", Toast.LENGTH_SHORT).show(); return }
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 1))
            .build()
        gestureBusy = true
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { gestureBusy = false }
            override fun onCancelled(gestureDescription: GestureDescription?) { gestureBusy = false }
        }, mainHandler)
        if (!accepted) gestureBusy = false
    }

    private fun removeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        removeBubble()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        const val PREFS = "point_tap_clicker_prefs"
        const val ACTION_SHOW = "com.example.pointtapclicker.SHOW"
        const val ACTION_HIDE = "com.example.pointtapclicker.HIDE"
    }
}
